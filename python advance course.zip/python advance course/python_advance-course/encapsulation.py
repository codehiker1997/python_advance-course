# Print Rectangular Patternpip
def regular_pattern(c1,c2,n):
    for i in range(n):
        for j in range(n):
            print(max(abs(c1-i), abs(c2-i)), end="  ")
c1 =4 
c2= 4
n=10



print(regular_pattern(c1,c2,n))

